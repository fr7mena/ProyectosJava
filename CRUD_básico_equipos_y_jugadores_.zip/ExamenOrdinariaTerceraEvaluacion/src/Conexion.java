import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private static Connection conexion;
    private static String URL = "jdbc:mariadb://localhost:3307/";
    private static String USR = "root";
    private static String PWD = "";

    private Conexion() {
        try {
            conexion = DriverManager.getConnection(URL, USR, PWD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static Connection getConexion() {
        if (conexion == null) {
            new Conexion();
        }
        return conexion;
    }
    public static void getDesconexion() {
        if (conexion != null) {
            try {
                conexion.close();
                System.out.println("Se ha cerrado la conexión correctamente.");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        conexion = null;
    }
}
