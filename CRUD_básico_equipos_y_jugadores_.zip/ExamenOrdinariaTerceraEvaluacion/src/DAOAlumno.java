import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DAOAlumno {
    private static Connection conexion;
    public DAOAlumno() {
        conexion = Conexion.getConexion();
    }
    /*Pedro Romero, 20, DA
Susana Ruiz, 22, DB
María Fernández, 20, DA
Daniel Sánchez, 20, DB
Juana Díaz, 23, DB
Sergio Alvarez, 21, DA
Óscar González, -20, DB
Ricardo Fernández, 22, DA
Ana López, 22, DA
Jorge Flores, 22, DA
César Pérez, 21, DB
*/
    public void leeYcargaRegistro(File fichero) {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(fichero));
             PreparedStatement ps = conexion.prepareStatement
                     (String.format("INSERT INTO %s (%s, %s, %s) VALUES (?, ?, ?)",
                             DDL.getTabla(),
                             DDL.getColumnas()[1], DDL.getColumnas()[2], DDL.getColumnas()[3]))) {
            while (true) {
                Alumno a = new Alumno(dis.readUTF(), dis.readInt(), dis.readUTF());
                ps.setString(1, a.getNombre());
                ps.setInt(2, a.getEdad()); //NO ME SALE LO DEL SET ALUMNO
                ps.setString(3, a.getGrupo());
                ps.executeUpdate();
            }
        }catch (EOFException e) {
            System.out.println("Se acabó la lectura del fichero.");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
