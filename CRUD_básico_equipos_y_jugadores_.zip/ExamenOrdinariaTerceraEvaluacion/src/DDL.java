import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DDL {
    //BD= ies
    //TABLA= alumno
    //COLUMNAS= id, nombre, edad, grupo
    //TIPOS= entero, cadena, entero, cadena
    private static Connection conexion;
    private static String bd;
    private static String tabla;
    private static String[] columnas;
    private static String[] tipos;
    private static String CREATEDATABASE = "CREATE DATABASE ";
    private static String USEDATABASE = "USE ";

    public DDL() {
        conexion = Conexion.getConexion();
    }

    public void leeYcargaVariables(File fichero) {
        try (Scanner scn = new Scanner(fichero)) {
           bd = scn.nextLine().split("\\s*[=]\\s*")[1].trim();
           tabla = scn.nextLine().split("\\s*[=]\\s*")[1].trim();
           columnas = scn.nextLine().split("\\s*[=]\\s*")[1].split("\\s*[,]\\s*");
           tipos = scn.nextLine().split("\\s*[=]\\s*")[1].replace("entero", "INT").replace("cadena", "VARCHAR").split("\\s*[,]\\s*");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void createDatabase() {
        try (Statement st = conexion.createStatement()) {
            st.executeQuery(CREATEDATABASE + bd);
            System.out.println("Se creó correctamente la base de datos");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void useDatabase() {
        try (Statement st = conexion.createStatement()) {
            st.executeQuery(USEDATABASE + bd);
            System.out.println("Se usa correctamente la base de datos");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void createTable() {//BD= ies
        //TABLA= alumno
        //COLUMNAS= id, nombre, edad, grupo
        //TIPOS= entero, cadena, entero, cadena
        try (Statement st = conexion.createStatement()) {
            st.executeUpdate(String.format("CREATE TABLE %s(" +
                    "%s %s AUTO_INCREMENT PRIMARY KEY," +
                    "%s %s(100)," +
                    "%s %s," +
                    "%s %s(50))", tabla,
                    columnas[0].trim(), tipos[0].trim(),
                    columnas[1].trim(), tipos[1].trim(),
                    columnas[2].trim(), tipos[2].trim(),
                    columnas[3].trim(), tipos[3].trim()
                    ));
            System.out.println("Se creó correctamente la tabla");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static Connection getConexion() {
        return conexion;
    }

    public static void setConexion(Connection conexion) {
        DDL.conexion = conexion;
    }

    public static String getBd() {
        return bd;
    }

    public static void setBd(String bd) {
        DDL.bd = bd;
    }

    public static String getTabla() {
        return tabla;
    }

    public static void setTabla(String tabla) {
        DDL.tabla = tabla;
    }

    public static String[] getColumnas() {
        return columnas;
    }

    public static void setColumnas(String[] columnas) {
        DDL.columnas = columnas;
    }

    public static String[] getTipos() {
        return tipos;
    }

    public static void setTipos(String[] tipos) {
        DDL.tipos = tipos;
    }
}
