import java.util.Objects;

public class Alumno implements Comparable<Alumno> {
    /*Pedro Romero, 20, DA
Susana Ruiz, 22, DB
María Fernández, 20, DA
Daniel Sánchez, 20, DB
Juana Díaz, 23, DB
Sergio Alvarez, 21, DA
Óscar González, -20, DB
Ricardo Fernández, 22, DA
Ana López, 22, DA
Jorge Flores, 22, DA
César Pérez, 21, DB
*/
    private String nombre;
    private int edad;
    private String grupo;

    public Alumno(String nombre, int edad, String grupo)  {
        this.nombre = nombre;
        setEdad(edad);
        this.grupo = grupo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad)  {
        if (edad > 0) {
            this.edad = edad;
        } //else throw new EdadException("La edad es negativa");
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Alumno alumno = (Alumno) o;
        return edad == alumno.edad && Objects.equals(nombre, alumno.nombre) && Objects.equals(grupo, alumno.grupo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, edad, grupo);
    }

    @Override
    public int compareTo(Alumno o) {
        return this.nombre.compareTo(o.getNombre());
    }
}
