public class EdadException extends Exception {
    public EdadException(String message) {
        super(message);
    }
}
