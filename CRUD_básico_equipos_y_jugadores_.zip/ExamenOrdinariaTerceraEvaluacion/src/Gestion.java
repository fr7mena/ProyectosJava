import java.io.File;
import java.util.Arrays;

public class Gestion {
    private static File metaDatos =new File("datos/meta-datos.txt");
    private static File tablaDatos =new File("datos/archivo.datos");
    public static void main(String[] args) throws EdadException {
        DDL ddl = new DDL();
        ddl.leeYcargaVariables(metaDatos);
        /*System.out.println(DDL.getBd());
        System.out.println(DDL.getTabla());
        System.out.println(Arrays.toString(DDL.getColumnas()));
        System.out.println(Arrays.toString(DDL.getTipos()));*/
        //ddl.createDatabase();
        ddl.useDatabase();
        //ddl.createTable();
        DAOAlumno dao = new DAOAlumno();
        dao.leeYcargaRegistro(tablaDatos);
    }
}
