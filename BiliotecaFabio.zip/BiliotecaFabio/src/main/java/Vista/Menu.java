package Vista;

import Controlador.ControlEjemplar;
import Controlador.ControlLibro;
import Controlador.ControlPrestamo;
import Controlador.ControlUsuario;
import Modelo.Usuario;

import java.util.Scanner;

public class Menu {
    public static Scanner sc = new Scanner(System.in);
    public static void muestraMenuInicial() {
        System.out.println("Bienvenido, seleccione una de las opciones que le ofrece nuestra gestión de la biblioteca: ");
        System.out.println("1. Registro de usuario.");
        System.out.println("2. Iniciar sesión.");
        System.out.println("3. Mostrar libros.");
        System.out.println("4. Salir.");

        switch (sc.next()) {
            case "1":
                ControlUsuario.registrarUsuario();
                break;
            case "2":
                ControlUsuario.iniciarSesion();
                break;
            case "3":
                ControlLibro.getAllLibros();
                break;
            case "4":
                System.out.println("Saliste del programa correctamente, adiós.");
                break;
            default:
                System.out.println("Opcion invalida");
                Menu.muestraMenuInicial();
                break;
        }

    }

    /*public static void gestionOpcionInicial() {
        switch (sc.next()) {
            case "1":
                ControlUsuario.registrarUsuario();
                break;
            case "2":
                ControlUsuario.iniciarSesion();
                break;
            default:
                System.out.println("Opcion invalida");
                Menu.muestraMenuInicial();
                break;
        }
    }
*/
    public static void muestraMenuNormal(Usuario usuario) {
        System.out.printf("Bienvenido, %s.\n", usuario.getNombre());
        System.out.println("¿Qué quieres hacer?, Elige una opción de las siguientes ");
        System.out.println("1. Visualizar tus prestamos.");
        System.out.println("2. Volver a menú principal.");

        switch (Menu.sc.next()) {
            case "1":
                ControlPrestamo.visualizarPrestamos(usuario);
                break;
            case "2":
                Menu.muestraMenuInicial();
                break;
        }
    }

    public static void muestraMenuAdministrador(Usuario usuario) {
        System.out.printf("Bienvenido, %s al menú del administrador:\n", usuario.getNombre());
        System.out.println("Elige una opción de las sigiuentes: ");
        System.out.println("1. Añadir un libro");
        System.out.println("2. Añadir un ejemplar");
        System.out.println("3. Visualizar el Stock disponible de un libro");
        System.out.println("4. Realizar un préstamo");
        System.out.println("5. Devolver un libro");
        System.out.println("6. Volver");

        switch (Menu.sc.next()) {
            case "1":
                ControlLibro.insertarLibro();
                break;
            case "2":
                ControlEjemplar.insertEjemplar();
                break;
            case "3":
                ControlEjemplar.getStock();
                break;
            case "4":
                ControlPrestamo.realizarPrestamo(usuario);
                break;
            
        }



    }

    /*public static void muestraMenuUAdmin(Usuario usuario) {
        System.out.println("Bienvenido administrador " + usuario.getNombre() + ", elija una opción: ");
        System.out.println("---------------------------------");
        System.out.println("1. Añadir un libro");
        System.out.println("2. Añadir un ejemplar");
        System.out.println("3. Stock disponible de un libro");
        System.out.println("4. Realizar un prestamo");
        System.out.println("5. Devolver un libro");
        System.out.println("6. Volver");
        elijeOpcionAdmin(usuario);
    }*/
}

