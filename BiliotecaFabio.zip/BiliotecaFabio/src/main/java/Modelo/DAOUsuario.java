package Modelo;

import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;

public class DAOUsuario extends DAOGenerico {

    public DAOUsuario(Class clase, Object o) {
        super(clase, o);
    }

    public Usuario getUsuarioByEmail(String email) {
        Usuario usuario = null;
        String sql = "SELECT * FROM usuario WHERE email = ?";
        Query query = em.createNativeQuery(sql, Usuario.class);
        query.setParameter(1, email);
        try {
            usuario = (Usuario) query.getSingleResult();
            return usuario;
        } catch (NoResultException e) {
            return usuario;
        }
    }
    /*public Usuario getUsuarioByCorreo(String correo) {
        String sql = "SELECT * FROM usuario WHERE email = ?";
        Query consulta = em.createNativeQuery(sql, Usuario.class);
        consulta.setParameter(1, correo);
        try {
            return (Usuario) consulta.getSingleResult();
        }catch (NoResultException nre){
            return null;
        }
    }*/
}
