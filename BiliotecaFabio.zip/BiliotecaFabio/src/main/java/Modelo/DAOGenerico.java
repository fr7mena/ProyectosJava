/*package Modelo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import java.util.List;

public class DAOGenerico <T, ID> {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("unidadBiblioteca"); //Esta es la unidad de persistencia que debe estar especificada en el persistence.xml
    EntityManager em = emf.createEntityManager(); //Este objeto se utiliza para realizar las operaciones de persistencia (como crear, leer, actualizar, eliminar entidades).
    EntityTransaction tx = em.getTransaction(); //Obtiene el objeto EntityTransaction desde el EntityManager, que es utilizado para controlar las transacciones de la base de datos (cuando se realiza una operación como insert, update o delete, es importante envolverlas en una transacción para garantizar la consistencia de los datos).

    private Class<T> clase;
    private ID id;

    public DAOGenerico(Class<T> clase, ID id) {
        this.clase = clase;
        this.id = id;
    }

    public void insert(T t) {
        tx.begin(); //Comienza una nueva transacción.
        em.persist(t); //Guarda la entidad t en la base de datos. t es una instancia de la clase de entidad T.
        *//*em.flush();*//*
        tx.commit(); //Si la inserción fue exitosa, se confirma la transacción, haciendo permanentes los cambios en la base de datos.
    }

    public T getById(ID id) {
        return em.find(clase, id); //em.find(clase, id);: Busca la entidad de tipo T (representada por clase) en la base de datos utilizando el identificador id. Devuelve la entidad encontrada o null si no se encuentra.
    }

    public List<T> getAll() {
        return em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e", clase).getResultList(); //el createQuery del EntityManager es un metodo que esta sobrecargado y que una de las opciones que acepta a la hora de pasar parámetros es la de pasar una string y una instancia de la clase T.
        //CURIOSIDAD DEL USO DE LA LETRA "e":
        // Si tuviéramos una clase Libro y ejecutamos la consulta SELECT e FROM Libro e, el alias e simplemente permite hacer referencias a las instancias de Libro dentro de la consulta de manera más clara y sencilla. Podríamos usar e para acceder a los campos de la entidad si agregamos condiciones o manipulamos los datos.
        // Por ejemplo:
        //SELECT e FROM Libro e WHERE e.titulo = 'Java Básico'
    }

    public void delete(T t) {
        tx.begin();
        em.remove(t); //Elimina la entidad t de la base de datos.
        tx.commit();
    }

    public void update(T t) {
        tx.begin();
        em.merge(t); //Actualiza la entidad t en la base de datos. Si la entidad ya existe, sus cambios se aplican; si no existe, se inserta.
        tx.commit();
    }
}*/
/*
Resumen del funcionamiento:
La clase DAOGen es un DAO genérico que permite realizar las operaciones básicas de persistencia (crear, leer, actualizar y eliminar) en cualquier entidad (T).
Utiliza JPA para interactuar con la base de datos a través de EntityManager, que maneja las transacciones y las consultas.
Las operaciones están envueltas en transacciones (tx.begin(), tx.commit()) para garantizar que las modificaciones sean atómicas (se realizan completamente o no se realizan en absoluto).
Este patrón facilita la reutilización del código para gestionar diferentes tipos de entidades sin necesidad de crear un DAO para cada tipo.*/
package Modelo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import java.util.List;


public class DAOGenerico<T, ID>{
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("unidadBiblioteca");
    EntityManager em = emf.createEntityManager();
    EntityTransaction tx = em.getTransaction();

    private Class<T> clase;
    private ID id;

    public DAOGenerico(Class<T> clase, ID id) {
        this.clase = clase;
        this.id = id;
    }

    public void insert(T t) {
        tx.begin();
        em.persist(t);
        tx.commit();
    }

    public T getById(ID id) {
        return em.find(clase, id);
    }

    public List<T> getAll() {
        return em.createQuery("SELECT e FROM " + clase.getSimpleName() + " e ", clase).getResultList();
    }

    public void delete(T t) {
        tx.begin();
        em.remove(t);
        tx.commit();
    }

    public void update(T t) {
        tx.begin();
        em.merge(t);
        tx.commit();
    }
}