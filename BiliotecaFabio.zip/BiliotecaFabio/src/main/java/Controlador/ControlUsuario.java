package Controlador;

import Modelo.DAOUsuario;
import Modelo.Usuario;
import Vista.Menu;

public class ControlUsuario  {
    private static final DAOUsuario daoUsuario = new DAOUsuario(Usuario.class, Integer.class);

    public static void registrarUsuario() {
        System.out.println("Registro de Usuario.");
        System.out.println("Introduzca su DNI: ");
        String dni = Menu.sc.next();
        System.out.println("Introduzca su nombre: ");
        String nombre = Menu.sc.next();
        System.out.println("Introduzca su email: ");
        String email = Menu.sc.next();
        System.out.println("Introduzca su password: ");
        String password = Menu.sc.next();
        System.out.println("Introduzca su tipo de usuario (A/N): ");
        String tipo = Menu.sc.next();

        Usuario usuario = new Usuario(dni, nombre, email, password, tipo.toUpperCase());

        if (daoUsuario.getUsuarioByEmail(email) == null) { //Aquí hay que poner algún try cath en el caso de que si por qué hay que hacerlo???? PREGUTAR A KAMEL ESTA ES LA UNICA VALIDACION QUE HE HECHO PORQUE EN EL ENUNCIADO NO SE ESPECIFICA NINGUNA PERO PODRÍA HABER ALGUNAS MAS.
            if (usuario.getTipo().equalsIgnoreCase("A")) {
                usuario.setTipo("administrador");
            } else {
                usuario.setTipo("normal");
            }
            daoUsuario.insert((Usuario) usuario);
            System.out.printf("El usuario %s ha sido registrado correctamente. %n", usuario.getNombre());
        } else {
            System.out.println("El usuario ya existe, prueba con otro correo electrónico.");
            Menu.muestraMenuInicial();
        }

/*
        public Usuario(String dni, String nombre, String email, String password, String tipo) {
            this.dni = dni;
            this.nombre = nombre;
            this.email = email;
            this.password = password;
            this.tipo = tipo;
        }
*/
    }

    public static void iniciarSesion() {
        System.out.println("Inicio de Sesión:");
        System.out.println("Introduzca su correo electrónico: ");
        String correo = Menu.sc.next();
        System.out.println("Introduzca su password: ");
        String password = Menu.sc.next();

        if (daoUsuario.getUsuarioByEmail(correo) != null) {
            Usuario usuario = daoUsuario.getUsuarioByEmail(correo);
            if (usuario.getPassword().equals(password)) {
                if (!usuario.getTipo().equalsIgnoreCase("administrador")) {
                    Menu.muestraMenuNormal(usuario);
                } else {
                    Menu.muestraMenuAdministrador(usuario);
                }
            }
        } else {
            System.out.println("El usuario no existe, si quiere podría registrarse.");
            Menu.muestraMenuInicial();
        }
    }

    public static Usuario getUsuarioById(Integer id) {
        return (Usuario) daoUsuario.getById(id);
    }



}
