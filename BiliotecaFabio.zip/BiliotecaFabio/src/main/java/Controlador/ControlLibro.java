package Controlador;

import Modelo.DAOGenerico;
import Modelo.Ejemplar;
import Modelo.Libro;
import Vista.Menu;

import java.util.List;

public class ControlLibro {
    private static final DAOGenerico daoLibro = new DAOGenerico<>(Libro.class, String.class); //Es IMPORTANTÍSIMOOOOO PONER LOS <> despues del nombre tipo de dato en este caso DAOGenerico, para que el compilador aprovecha las caracteristicas de tipado fuerte del lenguaje y prevenir errores de tipado, por ello simple debe de tener esta forma cuando se use genericos: DAOGenerico<>

    public static void insertarLibro() {
        System.out.println("Añadir libro: ");
        System.out.println("Introduce el ISBN del libro: ");
        String isbn = Menu.sc.next();
        System.out.println("Introduce el título del libro: ");
        String titulo = Menu.sc.next();
        System.out.println("Introduce el autor del libro: ");
        String autor = Menu.sc.next();

        Libro libro = new Libro(isbn, titulo, autor);
        daoLibro.insert(libro);
        try {
            ControlEjemplar.insertEjemplar(new Ejemplar(libro)); //POR QUÉ EL AL PASARLE UN LIBRO EL HIBERNATE PONE EN LA BASE DE DATOS EL ISBN NO LO ENTIENDOOOO PREGUNTAR A KAMEL!!!!
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
        System.out.println("Libro insertado correctamente");
        //Hay que añadir el ejemplar porque se entiende que si hay un libro es porque minimo hay un ejemplar.
    }

    public static Libro getLibroByIsbn(String isbn) {
        Libro libro = (Libro) daoLibro.getById(isbn);
        return libro;
        /*if (libro != null) {
            return libro;
        }
        System.out.printf("El libro de isbn -> %s no existe, pruebe a introducir el isbn de nuevo.\n", isbn);
        ControlEjemplar.insertEjemplar();
        return libro;*/
    }

    public static void getAllLibros() {
        List<Libro> listaLibros = (List<Libro>) daoLibro.getAll();
        for (Libro libro : listaLibros) {
            System.out.println(libro);
        }
    }

    /*public Libro(String isbn, String titulo, String autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
    }*/
}
