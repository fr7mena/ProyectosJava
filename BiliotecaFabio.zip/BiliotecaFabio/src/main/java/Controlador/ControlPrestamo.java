package Controlador;

import Modelo.*;
import Vista.Menu;

import java.time.LocalDate;

public class ControlPrestamo {
    private static final DAOGenerico daoPrestamo = new DAOGenerico<>(Prestamo.class, Integer.class);

public static void visualizarPrestamos(Usuario usuario) {
    System.out.println("Visualización de préstamos");
    if (usuario.getPrestamos().isEmpty()) {
        System.out.printf("El usuario %s no ha cogido ningún ejemplar prestado\n", usuario.getNombre());
    } else {
        System.out.printf("Los préstamos pendientes de %s son:\n", usuario.getNombre());
        for (Prestamo prestamo : usuario.getPrestamos()) {
            System.out.println(prestamo);
        }
    }
}

/*public static void realizarPrestamo(Usuario admin) {
    System.out.println("Dime el id del usuario que quiere realizar la prestamo.");
    Integer idUsuario = Menu.sc.nextInt();
    Menu.sc.nextLine();
    System.out.println("Dime el id del ejemplar que quieres tomar prestado.");
    Integer isbnEjemplar = Menu.sc.nextInt();
    if (ControlUsuario.getUsuarioById(idUsuario) != null) {
        Usuario usuario = ControlUsuario.getUsuarioById(idUsuario);
        Ejemplar ejemplar = ControlEjemplar.getEjemplarById(isbnEjemplar);
        if (ejemplar != null) {
            //Un usuario no puede tener mas de tres prestamos:
            if (usuario.getPrestamos().size() < 3) {
                if (usuario.getPenalizacionHasta() == null) {
                    ejemplar.setEstado("Prestado");
                    ControlEjemplar.actualizarEjemplar(ejemplar);
                    LocalDate fechaInicio = LocalDate.now();
                    LocalDate fechaFinal = LocalDate.now().plusDays(15);
                    Prestamo prestamo = new Prestamo(*//*null, *//*usuario, ejemplar, fechaInicio, fechaFinal); //HE cambiado el constructor y esta linea añadiendo el id en el cons y el 0 en el parametro
                    *//*usuario.getPrestamos().add(prestamo);*//*
                    *//*try {*//*
                        daoPrestamo.insert(prestamo);
                    *//*} catch (RuntimeException e) {
                        e.printStackTrace();
                    }*//*
                    System.out.printf("Ejemplar -> %s del libro -> %s prestado correctamente. %s, tienes hasta el día %s para devolverlo %n", ejemplar.getId(), ejemplar.getIsbn().getTitulo(), usuario.getNombre(), fechaFinal);
                } else {
                    System.out.printf("El usuario %s no puede coger prestado ningún ejemplar porque tiene una penalización activa hasta el %s %n", usuario.getNombre(), usuario.getPenalizacionHasta()*//*.toString()*//*);
                }
            } else {
                System.out.printf("El usuario %s ya tiene 3 ejemplares en préstamo y no puede alquinar más ejemplares hasta que no acabe uno de sus préstamos %n", usuario.getNombre());
                Menu.muestraMenuAdministrador(admin);
            }
        } else {
            System.out.printf("El libro no se puede prestar porque no tienen ningún ejemplar disponible.%n");
        }
    } else {
        System.out.printf("El id de usuario que has facilitado no se encuentra en nuestra base de datos, ¿el cliente se quiere registrar?. (S/N/Cualquier otra cosa)", idUsuario);
        String respuesta = Menu.sc.next();
        switch (respuesta) {
            case "S":
                Menu.muestraMenuInicial();
                break;
            case "N":
                System.out.printf("Perfecto, entonces puede ser que se hayas introducido mal tu id de usuario -> %s, repítemlo.%n", idUsuario);
                realizarPrestamo(admin);
                break;
            default:
                System.out.println("Adiós, cerrando programa de gestión de usuario.");
                break;
        }
    }*/

    /*public Prestamo(Usuario usuario, Ejemplar ejemplar, LocalDate fechaInicio, LocalDate fechaDevolucion) {
        this.usuario = usuario;
        this.ejemplar = ejemplar;
        this.fechaInicio = fechaInicio;
        this.fechaDevolucion = fechaDevolucion;
    }*/

    public static void realizarPrestamo(Usuario admin) {
        System.out.println("Dime el id del usuario que quiere realizar la prestamo.");
        Integer idUsuario = Menu.sc.nextInt();
        Menu.sc.nextLine();
        System.out.println("Dime el isbn del libro que quieres tomar prestado.");
        String isbnEjemplar = Menu.sc.nextLine();
        if (ControlUsuario.getUsuarioById(idUsuario) != null) {
            Usuario usuario = ControlUsuario.getUsuarioById(idUsuario);
            Ejemplar ejemplar = ControlEjemplar.getEjemplarByIsbnDisponible(String.valueOf(isbnEjemplar));
            if (ejemplar != null) {
                //Un usuario no puede tener mas de tres prestamos:
                if (usuario.getPrestamos().size() < 3) {
                    if (usuario.getPenalizacionHasta() == null) {
                        ejemplar.setEstado("Prestado");
                        ControlEjemplar.actualizarEjemplar(ejemplar);
                        LocalDate fechaInicio = LocalDate.now();
                        LocalDate fechaFinal = LocalDate.now().plusDays(15);
                        Prestamo prestamo = new Prestamo(usuario, ejemplar, fechaInicio, fechaFinal); //HE cambiado el constructor y esta linea añadiendo el id en el cons y el 0 en el parametro
                        usuario.getPrestamos().add(prestamo);
                        daoPrestamo.insert(prestamo);
                        System.out.printf("Ejemplar -> %s del libro -> %s prestado correctamente. %s, tienes hasta el día %s para devolverlo %n", ejemplar.getId(), ejemplar.getIsbn().getTitulo(), usuario.getNombre(), fechaFinal);
                    } else {
                        System.out.printf("El usuario %s no puede coger prestado ningún ejemplar porque tiene una penalización activa hasta el %s %n", usuario.getNombre(), usuario.getPenalizacionHasta().toString());
                    }
                } else {
                    System.out.printf("El usuario %s ya tiene 3 ejemplares en préstamo y no puede alquinar más ejemplares hasta que no acabe uno de sus préstamos %n", usuario.getNombre());
                    Menu.muestraMenuAdministrador(admin);
                }
            } else {
                System.out.printf("El libro no se puede prestar porque no tienen ningún ejemplar disponible.%n");
            }
        } else {
            System.out.printf("El id de usuario que has facilitado no se encuentra en nuestra base de datos, ¿el cliente se quiere registrar?. (S/N/Cualquier otra cosa)", idUsuario);
            String respuesta = Menu.sc.next();
            switch (respuesta) {
                case "S":
                    Menu.muestraMenuInicial();
                    break;
                case "N":
                    System.out.printf("Perfecto, entonces puede ser que se hayas introducido mal tu id de usuario -> %s, repítemlo.%n", idUsuario);
                    realizarPrestamo(admin);
                    break;
                default:
                    System.out.println("Adiós, cerrando programa de gestión de usuario.");
                    break;
            }
        }


}


}
