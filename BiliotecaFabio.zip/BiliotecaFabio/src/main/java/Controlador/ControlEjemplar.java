package Controlador;

import Modelo.DAOGenerico;
import Modelo.Ejemplar;
import Modelo.Libro;
import Vista.Menu;

import java.util.List;

public class ControlEjemplar {
    private static final DAOGenerico daoEjemplar = new DAOGenerico<>(Ejemplar.class, Integer.class);

    public static void insertEjemplar() {
        System.out.println("Introduce el ISBN del libro: ");
        String isbn = Menu.sc.next();
        Libro libro = (Libro) ControlLibro.getLibroByIsbn(isbn);
        if (libro == null) {
            System.out.printf("El libro de isbn -> %s no existe, pruebe a introducir el isbn de nuevo.\n", isbn);
            insertEjemplar();
        }
        Ejemplar ejemplar = new Ejemplar(libro);
        daoEjemplar.insert(ejemplar);
        System.out.printf("El ejempla de isbn -> %s ha sido registrado correctamente.%n", isbn);
    }

    public static void insertEjemplar(Ejemplar ejemplar) {
        daoEjemplar.insert(ejemplar);
    }

    public static void getStock () {
        System.out.println("Introduce el ISBN del libro que te interesa: ");
        String isbn = Menu.sc.next();
        Integer stock = 0;
        List<Ejemplar> ejemplaresAll = /*(List<Ejemplar>)*/daoEjemplar.getAll();

        for (Ejemplar ejemplar : ejemplaresAll) {
            if (ejemplar.getIsbn().getIsbn().equals(isbn) && ejemplar.getEstado().equalsIgnoreCase("Disponible")) { /*RECORDAR QUE EN LA CLASE Ejemplar EL MÉTODO getIsbn() te devolvía un Libro libro y para acceder a su atributo String isbn del Libro es necesario poner dos veces el método getIsbn() uno para acceder al libro desde lo clase ejemplar y otro para acceder al String isbn de la clase Libro.*/
                stock++;
            }
        }
        System.out.printf("El ejemplar de ISBN -> %s tiene un stock de %s unidades\n", isbn, stock);
    }

    public static Ejemplar getEjemplarById(Integer id) {
        return (Ejemplar) daoEjemplar.getById(id);
    }

    public static void actualizarEjemplar(Ejemplar ejemplar) {
        daoEjemplar.update(ejemplar);
    }

    public static Ejemplar getEjemplarByIsbnDisponible(String isbn) {
        List<Ejemplar> listaEjemplares = (List<Ejemplar>) daoEjemplar.getAll();
        for (Ejemplar ejemplar : listaEjemplares) {
            if (ejemplar.getIsbn().getIsbn().equals(isbn) && ejemplar.getEstado().equalsIgnoreCase("Disponible")) {
                return ejemplar;
            }
        }
        return null;
    }
}
